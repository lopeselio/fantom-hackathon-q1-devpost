export enum EVENTS_NAME {
  gameEnd = 'game-end',
  chestLoot = 'chest-loot',
  attack = 'attack',
}

export enum GameStatus {
  WIN,
  LOSE,
}
