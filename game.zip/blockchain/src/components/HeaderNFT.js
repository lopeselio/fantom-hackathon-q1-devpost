import React from 'react'
import '../styles/booth.css'


export default function Header(props) {
    return (
    <div className="header-booth">
      <div className="navbar">
      <a href="/selection" class="active" className='navbox text-header1'>Home</a>
      </div>
      </div>
    )
}